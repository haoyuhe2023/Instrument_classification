# -*- coding = utf-8 -*-
# @Time: 2022/10/18 14:52
# @Author：HaoYu.HE
# @File:instrument_classifier_CNN.py
# @software:PyCharm

## Code Inspired by:
# Valerio Velardo https://github.com/musikalkemist/DeepLearningForAudioWithPython/tree/master/16-%20How%20to%20implement%20a%20CNN%20for%20music%20genre%20classification/code
## whose code is used as a reference. The source code uses a different dataset. Some complex steps of the source code was imporved by us.

## Model Inspired by:
### Arsh Chowdhry: https://www.clairvoyant.ai/blog/music-genre-classification-using-cnn
## The model in the source used several Dropout Layer, we simplyfied the model in our case



import json
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow import keras
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

print("start")

data_path = "D:\pythonProject6\data_11.json"


def load_data(dataset_path):
    with open(dataset_path, "r")as fp:
        data = json.load(fp)

        # convert the lists into numpy arrays
    x = np.array(data["mfcc"])
    y = np.array(data["labels"])
    return x, y

    # plot


def plot_res(result):
    fig, axs = plt.subplots(2)

    # accuracy subplot
    axs[0].plot(result.result["accuracy"], label="train accuracy")
    axs[0].plot(result.result["val_accuracy"], label="test accuracy")
    axs[0].set_ylabel("Accuracy")
    axs[0].legend(loc="lower right")
    axs[0].set_title("Accuracy evaluation")

    # error subplot
    axs[1].plot(result.result["loss"], label="training error")
    axs[1].plot(result.result["val_loss"], label="testing error")
    axs[1].set_ylabel("Error")
    axs[1].set_xlabel("Epochs")
    axs[1].legend(loc="upper right")
    axs[1].set_title("Error evaluation")

    plt.show()


def data_prepare(test_size, validation_size):
    # data loading
    x, y = load_data(data_path)
    # split train/test set
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=test_size)
    # split train/validation set
    x_train, x_validation, y_train, y_validation = train_test_split(x_train, y_train, test_size=validation_size)

    x_train = x_train[..., np.newaxis]
    x_validation = x_validation[..., np.newaxis]
    x_test = x_test[..., np.newaxis]

    return x_train, x_validation, x_test, y_train, y_validation, y_test


def model_build(input_shape):
    model = keras.Sequential()

    # building the first convolution layer
    model.add(keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape))
    model.add(keras.layers.MaxPool2D((3, 3), strides=(2, 2), padding="same"))
    model.add(keras.layers.BatchNormalization())  # BatchNormalization

    # second convolution layer
    model.add(keras.layers.Conv2D(32, (3, 3), activation='relu'))
    model.add(keras.layers.MaxPool2D((3, 3), strides=(2, 2), padding="same"))
    model.add(keras.layers.BatchNormalization())

    # third convolution layer
    model.add(keras.layers.Conv2D(32, (2, 2), activation='relu'))
    model.add(keras.layers.MaxPool2D((2, 2), strides=(2, 2), padding="same"))
    model.add(keras.layers.BatchNormalization())

    # flatten output and dense layer
    model.add(keras.layers.Flatten())
    model.add(keras.layers.Dense(64, activation="relu"))
    model.add(keras.layers.Dropout(0.3))

    # output layer
    model.add(keras.layers.Dense(11, activation='softmax'))

    return model


if __name__ == "__main__":
    # training, validation,test sets
    x_train, x_validation, x_test, y_train, y_validation, y_test = data_prepare(0.25, 0.2)

    # building the CNN net model
    input_shape = (x_train.shape[1], x_train.shape[2], x_train.shape[3])

    model = model_build(input_shape)

    optimizer = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])

    model.summary()
    # train the model
    result = model.fit(x_train, y_train, validation_data=(x_validation, y_validation), batch_size=32, epochs=60)
    plot_res(result)

    # evaluation
    test_error, test_accuracy = model.evaluate(x_test, y_test, verbose=2)
    print("Loss:", test_error, " Accuracy:", test_accuracy)

    # prediction
    prediction = model.predict(x_test)
    predicted_index = np.argmax(prediction, axis=1)

    c_m = confusion_matrix(y_test, predicted_index)
    print(c_m)
