# -*- coding = utf-8 -*-
# @Time: 2022/10/21 16:31
# @Author：HaoYu.HE
# @File:sample.py
# @software:PyCharm

import librosa
import matplotlib.pyplot as plt
from librosa import display


file = "D:\download2\IRMAS-TrainingData/pia\[pia][cla]1283__1.wav"
signal, sr = librosa.load(file, sr=44100)
n_fft = 2048
hop_length = 512
MFCCs = librosa.feature.mfcc(signal, n_fft=n_fft, hop_length=hop_length, n_mfcc=13)

# plot
librosa.display.specshow(MFCCs, sr=sr, hop_length=hop_length)
plt.xlabel("Time")
plt.ylabel("MFCC")
plt.colorbar
plt.title("MFCC OF piano")
plt.show()
